export interface City {
  id: number;
  city: string;
}
